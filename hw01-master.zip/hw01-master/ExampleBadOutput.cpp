#include <iostream>

#include <string>
#include <fstream>

using namespace std;

int main( int argc, char** argv )
{
	cout << "Meredith" << "\t" << "Invoice" << "\t" << "PARK-1203; PARK-1205; TECH-3034" << endl;
	cout << "Jackson" << "\t" << "Approve-reservation" << "\t" << "7634" << endl;
	cout << "Amelia" << "\t" << "Approve-reservation" << "\t" << "7658; 7664" << endl;
	cout << "Jackson" << "\t" << "Invoice" << "\t" << "DISC-7303, DISC-7343" << endl;
	cout << "Callie" << "\t" << "Approve-travel" << "\t" << "TR-N208-TX; TR-N209-TX" << endl;
	cout << "Arizona" << "\t" << "Invoice" << "\t" << "DISC-7304(Cancelled)" << endl;
	cout << "Cristina" << "\t" << "Invoice" << "\t" << "TECH-3030, TECH-2980(Cancelled)" << endl;
	cout << "Owen" << "\t" << "Approve-purchase-order" << "\t" << "D-9077; D-9078" << endl;
	cout << "Callie" << "\t" << "Invoice" << "\t" << "DISC-7294" << endl;
	cout << "Miranda" << "\t" << "Purchase-order-cancellation" << "\t" << "D-9076" << endl;
	cout << "Callie" << "\t" << "Review-invoice" << "\t" << "DISC-7304" << endl;
}

